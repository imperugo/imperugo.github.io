﻿using System.Web.Http;

namespace DemoWorkerRole.APIs
{
	public class DemoController : ApiController
	{
		public string Get(string id)
		{
			return string.Format("The parameter value is {0}", id);
		}
	}
}