using System;
using System.Diagnostics;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Owin.Hosting;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace DemoWorkerRole
{
	public class WorkerRole : RoleEntryPoint
	{
		private readonly CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
		private readonly ManualResetEvent runCompleteEvent = new ManualResetEvent(false);

		private IDisposable app;

		public override void Run()
		{
			Trace.TraceInformation("WorkerRole is running");

			try
			{
				RunAsync(cancellationTokenSource.Token).Wait();
			}
			finally
			{
				runCompleteEvent.Set();
			}
		}

		public override bool OnStart()
		{
			// Set the maximum number of concurrent connections
			ServicePointManager.DefaultConnectionLimit = 12;

			string baseUri = String.Format("{0}://{1}:{2}", RoleEnvironment.GetConfigurationSettingValue("protocol"),
				RoleEnvironment.GetConfigurationSettingValue("domain"),
				RoleEnvironment.GetConfigurationSettingValue("port"));

			Trace.TraceInformation(String.Format("Starting OWIN at {0}", baseUri), "Information");

			try
			{
				app = WebApp.Start<Startup>(new StartOptions(url: baseUri));
			}
			catch (Exception e)
			{
				Trace.TraceError(e.ToString());
				throw;
			}

			bool result = base.OnStart();

			Trace.TraceInformation("WorkerRole has been started");

			return result;
		}

		public override void OnStop()
		{
			Trace.TraceInformation("WorkerRole is stopping");

			cancellationTokenSource.Cancel();
			runCompleteEvent.WaitOne();

			if (app != null)
			{
				app.Dispose();
			}

			base.OnStop();

			Trace.TraceInformation("WorkerRole has stopped");
		}

		private async Task RunAsync(CancellationToken cancellationToken)
		{
			// TODO: Replace the following with your own logic.
			while (!cancellationToken.IsCancellationRequested)
			{
				//Trace.TraceInformation("Working");
				await Task.Delay(1000);
			}
		}
	}
}